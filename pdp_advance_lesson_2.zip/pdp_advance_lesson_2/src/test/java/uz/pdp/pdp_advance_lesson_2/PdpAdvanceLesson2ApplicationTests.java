package uz.pdp.pdp_advance_lesson_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdpAdvanceLesson2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
