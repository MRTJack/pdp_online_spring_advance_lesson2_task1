package uz.pdp.pdp_advance_lesson_2.task1.projectionInterface;

import org.springframework.data.rest.core.config.Projection;
import uz.pdp.pdp_advance_lesson_2.task1.entity.Client;

@Projection(name = "clientProjection", types = Client.class)
public interface ClientProjection {
    Long getId();

    String getName();

    String getPhoneNumber();
}
