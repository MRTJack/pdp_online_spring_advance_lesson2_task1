package uz.pdp.pdp_advance_lesson_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdpAdvanceLesson2Application {

    public static void main(String[] args) {
        SpringApplication.run(PdpAdvanceLesson2Application.class, args);
    }

}
