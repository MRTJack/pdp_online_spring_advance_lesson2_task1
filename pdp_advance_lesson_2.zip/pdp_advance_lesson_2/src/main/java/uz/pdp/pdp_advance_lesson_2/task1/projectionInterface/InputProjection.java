package uz.pdp.pdp_advance_lesson_2.task1.projectionInterface;

import org.springframework.data.rest.core.config.Projection;
import uz.pdp.pdp_advance_lesson_2.task1.entity.Input;

import java.util.Date;

@Projection(name = "inputProjection", types = Input.class)
public interface InputProjection {
    Long getId();

    Date getDate();

    Long getWarehouseId();

    Long getSupplierId();

    Long getCurrencyId();

    String getFactureNumber();

    String getCode();
}
