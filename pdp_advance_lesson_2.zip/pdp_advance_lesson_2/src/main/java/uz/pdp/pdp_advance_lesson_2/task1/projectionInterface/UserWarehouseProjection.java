package uz.pdp.pdp_advance_lesson_2.task1.projectionInterface;

import org.apache.catalina.User;
import org.springframework.data.rest.core.config.Projection;
import uz.pdp.pdp_advance_lesson_2.task1.entity.UserWarehouse;
import uz.pdp.pdp_advance_lesson_2.task1.entity.Warehouse;

@Projection(name = "userWarehouseProjection", types = UserWarehouse.class)
public interface UserWarehouseProjection {
    Long getId();

    User getUser();

    Warehouse getWarehouse();
}
