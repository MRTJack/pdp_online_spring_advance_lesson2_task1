package uz.pdp.pdp_advance_lesson_2.task1.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import uz.pdp.pdp_advance_lesson_2.task1.entity.Input;

public interface InputRepository extends JpaRepository<Input, Long> {
}
