package uz.pdp.pdp_advance_lesson_2.task1.projectionInterface;

import org.springframework.data.rest.core.config.Projection;
import uz.pdp.pdp_advance_lesson_2.task1.entity.Output;

import java.util.Date;

@Projection(name = "outputProjection", types = Output.class)
public interface OutputProjection {
    Long getId();

    Date getDate();

    Long getWarehouseId();

    Long getCurrencyId();

    String getFactureNumber();

    String getCode();

    Long getClientId();
}
