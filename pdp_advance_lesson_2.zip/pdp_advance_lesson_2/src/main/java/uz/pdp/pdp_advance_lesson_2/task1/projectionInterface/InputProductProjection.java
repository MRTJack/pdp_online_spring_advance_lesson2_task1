package uz.pdp.pdp_advance_lesson_2.task1.projectionInterface;

import org.springframework.data.rest.core.config.Projection;
import uz.pdp.pdp_advance_lesson_2.task1.entity.Input;
import uz.pdp.pdp_advance_lesson_2.task1.entity.InputProduct;
import uz.pdp.pdp_advance_lesson_2.task1.entity.Product;

import java.math.BigDecimal;
import java.util.Date;

@Projection(name = "inputProductProjection", types = InputProduct.class)
public interface InputProductProjection {
    Long getId();

    Product getProduct();

    int getAmount();

    BigDecimal getPrice();

    Date getExpireDate();

    Input getInput();
}
