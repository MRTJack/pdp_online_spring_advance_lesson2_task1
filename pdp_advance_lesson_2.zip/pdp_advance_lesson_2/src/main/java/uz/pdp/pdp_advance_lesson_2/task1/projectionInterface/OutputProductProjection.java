package uz.pdp.pdp_advance_lesson_2.task1.projectionInterface;

import org.springframework.data.rest.core.config.Projection;
import uz.pdp.pdp_advance_lesson_2.task1.entity.Output;
import uz.pdp.pdp_advance_lesson_2.task1.entity.OutputProduct;
import uz.pdp.pdp_advance_lesson_2.task1.entity.Product;

import java.math.BigDecimal;

@Projection(name = "outputProductProjection", types = OutputProduct.class)
public interface OutputProductProjection {
    Long getId();

    Product getProduct();

    int getAmount();

    BigDecimal getPrice();

    Output getOutput();
}
