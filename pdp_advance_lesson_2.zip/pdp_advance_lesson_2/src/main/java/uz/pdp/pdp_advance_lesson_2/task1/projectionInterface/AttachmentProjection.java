package uz.pdp.pdp_advance_lesson_2.task1.projectionInterface;

import org.springframework.data.rest.core.config.Projection;
import uz.pdp.pdp_advance_lesson_2.task1.entity.Attachment;

@Projection(name = "attachmentProjection", types = Attachment.class)
public interface AttachmentProjection {
    Long getId();

    String getName();

    Long getSize();

    String getContentType();

    byte[] getAttachmentContent();
}
