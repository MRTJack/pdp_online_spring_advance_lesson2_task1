package uz.pdp.pdp_advance_lesson_2.task1.projectionInterface;

import org.springframework.data.rest.core.config.Projection;
import uz.pdp.pdp_advance_lesson_2.task1.entity.Measurement;

@Projection(name = "measurementProjection", types = Measurement.class)
public interface MeasurementProjection {
    Long getId();

    String getName();

    boolean isActive();
}
