package uz.pdp.pdp_advance_lesson_2.task1.projectionInterface;

import org.apache.catalina.User;
import org.springframework.data.rest.core.config.Projection;

@Projection(name = "userProjection", types = User.class)
public interface UserProjection {
    Long getId();

    String getFirstName();

    String getLastName();

    String getPhoneNumber();

    String getCode();

    boolean isActive();
}
