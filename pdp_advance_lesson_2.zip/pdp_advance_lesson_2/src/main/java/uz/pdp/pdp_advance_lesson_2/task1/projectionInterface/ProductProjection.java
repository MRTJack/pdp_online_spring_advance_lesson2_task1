package uz.pdp.pdp_advance_lesson_2.task1.projectionInterface;

import org.springframework.data.rest.core.config.Projection;
import uz.pdp.pdp_advance_lesson_2.task1.entity.Product;

@Projection(name = "productProjection", types = Product.class)
public interface ProductProjection {
    Long getId();

    String getName();

    Long getCategoryId();

    Long getPhotoId();

    String getCode();

    Long getMeasurementId();

    boolean isActive();
}
