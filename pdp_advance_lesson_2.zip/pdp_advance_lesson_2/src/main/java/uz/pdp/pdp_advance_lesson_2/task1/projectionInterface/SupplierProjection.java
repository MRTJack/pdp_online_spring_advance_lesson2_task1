package uz.pdp.pdp_advance_lesson_2.task1.projectionInterface;

import org.springframework.data.rest.core.config.Projection;
import uz.pdp.pdp_advance_lesson_2.task1.entity.Supplier;
import uz.pdp.pdp_advance_lesson_2.task1.entity.UserWarehouse;

@Projection(name = "supplierProjection", types = Supplier.class)
public interface SupplierProjection {
    Long getId();

    String getName();

    boolean isActive();

    String getPhoneNumber();

    UserWarehouse getUserWarehouse();
}
